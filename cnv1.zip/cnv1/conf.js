{
  // コンバート設定ファイル

  // 変換元ディレクトリ (注：\記号は \\ でエスケープ)
  srcDir: 'D:\\yamada\\dev\\cnv1\\src',

  // 変換出力ディレクトリ (注：\記号は \\ でエスケープ)
  dstDir: 'D:\\yamada\\dev\\cnv1\\dst',

  // ログ出力ファイル (注：\記号は \\ でエスケープ)
  logFile: 'D:\\yamada\\dev\\cnv1\\log.txt',

  // コンバート対象ファイルの拡張子
  extsCnv: [
    'txt'
  ],

  // コンバート対象かつ shift-jis ファイルの拡張子
  extsSjis: [
    'txt'
  ],

  // コピー対象外ディレクトリ
  noCopyDirs: [
    'CVS'
  ],

  // 変換文字列セット(注：from は正規表現。 \記号は \\ でエスケープ。)
  // ＊変換処理はファイル名およびファイル内容に対して行われます
  replaceSets: [
    { from: '^.+\\\\4B51.jpeg', to: ''},
    { from: '^.+\\\\4B52.jpeg', to: ''},
    { from: '^.+\\\\4C9.jpeg', to: ''},
    { from: '^.+\\\\4CA.jpeg', to: ''},
    { from: '^.+\\\\4CB1.jpeg', to: ''},
    { from: '^.+\\\\4CB2.jpeg', to: ''},
    { from: '^.+\\\\GC-125C.jpeg', to: ''},
    { from: '^.+\\\\GQC105A.jpeg', to: ''},
    { from: '^.+\\\\GQC105B.jpeg', to: ''},
    { from: '^.+\\\\GQC125A.jpeg', to: ''},
    { from: '^.+\\\\GQC125B.jpeg', to: ''},
    { from: '^.+\\\\GQC125C.jpeg', to: ''},
    { from: '^.+\\\\GQC134A.jpeg', to: ''},
    { from: '^.+\\\\GQC164A.jpeg', to: ''},
    { from: '^.+\\\\GQC164B.jpeg', to: ''},
    { from: '^.+\\\\GQC164C.jpeg', to: ''},
    { from: '^.+\\\\GQC164D.jpeg', to: ''},
    { from: '^.+\\\\GQC164E.jpeg', to: ''},
    { from: '^.+\\\\GQC754A.jpeg', to: ''},
    { from: '^.+\\\\GQC755A.jpeg', to: ''},
    { from: '^.+\\\\GQC755B.jpeg', to: ''},
    { from: '^.+\\\\GQC755C.jpeg', to: ''},
    { from: '^.+\\\\GQC905A.jpeg', to: ''},
    { from: '^.+\\\\GQC905B.jpeg', to: ''},
    { from: '^.+\\\\GQC905C.jpeg', to: ''},
    { from: '^.+\\\\GQC905D.jpeg', to: ''},
    { from: '^.+\\\\GQUD07C.jpeg', to: ''},
    { from: '^.+\\\\GQUD07D.jpeg', to: ''},
    { from: '^.+\\\\GQUD09D.jpeg', to: ''},
    { from: '^.+\\\\GQUD09E.jpeg', to: ''},
    { from: '^.+\\\\GQUD09F.jpeg', to: ''},
    { from: '^.+\\\\GQUD12B.jpeg', to: ''},
    { from: '^.+\\\\GQUR06C.jpeg', to: ''},
    { from: '^.+\\\\GQUR06D.jpeg', to: ''},
    { from: '^.+\\\\GQUR07D.jpeg', to: ''},
    { from: '^.+\\\\GQUR09G.jpeg', to: ''},
    { from: '^.+\\\\GQUR09H.jpeg', to: ''},
    { from: '^.+\\\\GQUR09I.jpeg', to: ''},
    { from: '^.+\\\\GQUR09J.jpeg', to: ''},
    { from: '^.+\\\\GQUR10B.jpeg', to: ''},
    { from: '^.+\\\\GQUR12D.jpeg', to: ''},
    { from: '^.+\\\\GQUR12E.jpeg', to: ''},
    { from: '^.+\\\\GQUR12F.jpeg', to: ''},
    { from: '^.+\\\\GQUR13B.jpeg', to: ''},
    { from: '^.+\\\\P-03BK.jpeg', to: ''},
    { from: '^.+\\\\P-03DK.jpeg', to: ''},
    { from: '^.+\\\\P-04BK.jpeg', to: ''},
    { from: '^.+\\\\P-06AK.jpeg', to: ''},
    { from: '^.+\\\\P-08A.jpeg', to: ''},
    { from: '^.+\\\\P-10AK.jpeg', to: ''},
    { from: '^.+\\\\P-10BK.jpeg', to: ''},
    { from: '^.+\\\\P-12AK.jpeg', to: ''},
    { from: '^.+\\\\S-12SA.jpeg', to: ''},
    { from: '^.+\\\\S-12SC.jpeg', to: ''},
    { from: '^.+\\\\S-12UB.jpeg', to: ''},
    { from: '^.+\\\\S-15SB.jpeg', to: ''},
    { from: '^.+\\\\S-15SC.jpeg', to: ''},
    { from: '^.+\\\\S-16DC.jpeg', to: ''},
    { from: '^.+\\\\S-16SB.jpeg', to: ''},
    { from: '^.+\\\\S-16SF.jpeg', to: ''},
    { from: '^.+\\\\S-16SG.jpeg', to: ''},
    { from: '^.+\\\\S-16SH.jpeg', to: ''},
    { from: '^.+\\\\S-16SI.jpeg', to: ''},
    { from: '^.+\\\\S-16SJ.jpeg', to: ''},
    { from: '^.+\\\\S-16SK.jpeg', to: ''},
    { from: '^.+\\\\S-16SL.jpeg', to: ''},
    { from: '^.+\\\\S-16UC.jpeg', to: ''},
    { from: '^.+\\\\S-16UD.jpeg', to: ''},
    { from: '^.+\\\\S-16UE.jpeg', to: ''},
    { from: '^.+\\\\S-18SB.jpeg', to: ''},
    { from: '^.+\\\\S-25SB.jpeg', to: ''},
    { from: '^.+\\\\S-25SC.jpeg', to: ''},
    { from: '^.+\\\\UT-07C.jpeg', to: ''},
    { from: '^.+\\\\UT-07E.jpeg', to: ''},
    { from: '^.+\\\\UT-07F.jpeg', to: ''},
    { from: '^.+\\\\UT-07G.jpeg', to: ''},
    { from: '^.+\\\\UT-07H.jpeg', to: ''},
    { from: '^.+\\\\UT-07I.jpeg', to: ''},
    { from: '^.+\\\\UT-09A.jpeg', to: ''},
    { from: '^.+\\\\UT-09B.jpeg', to: ''},
    { from: '^.+\\\\UT-09C.jpeg', to: ''},
    { from: '^.+\\\\UT-09D.jpeg', to: ''},
    { from: '^.+\\\\UT-09E.jpeg', to: ''},
    { from: '^.+\\\\UT-09F.jpeg', to: ''},
    { from: '^.+\\\\UT-09G.jpeg', to: ''},
    { from: '^.+\\\\UT-09H.jpeg', to: ''},
    { from: '^.+\\\\UT-09I.jpeg', to: ''},
    { from: '^.+\\\\UT-09J.jpeg', to: ''},
    { from: '^.+\\\\UT-09K.jpeg', to: ''},
    { from: '^.+\\\\UT-09L.jpeg', to: ''},
    { from: '^.+\\\\UT-09M.jpeg', to: ''},
    { from: '^.+\\\\UT-09N.jpeg', to: ''},
    { from: '^.+\\\\UT-09P.jpeg', to: ''},
    { from: '^.+\\\\UT-10A.jpeg', to: ''},
    { from: '^.+\\\\UT-10B.jpeg', to: ''},
    { from: '^.+\\\\UT-12B.jpeg', to: ''},
    { from: '^.+\\\\UT-12C.jpeg', to: ''},
    { from: '^.+\\\\UT-12D.jpeg', to: ''},
    { from: '^.+\\\\UT-12E.jpeg', to: ''},
    { from: '^.+\\\\UT-12F.jpeg', to: ''},
    { from: '^.+\\\\UT-12G.jpeg', to: ''},
    { from: '^.+\\\\UT-12H.jpeg', to: ''},
    { from: '^.+\\\\UT-15A.jpeg', to: ''},
    { from: '^.+\\\\UT-15B.jpeg', to: ''}
  ]

}
